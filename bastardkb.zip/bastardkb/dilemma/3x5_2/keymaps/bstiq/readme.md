# Dilemma @bstiq keymap

Inspired from Miryoku, using home-rows.
