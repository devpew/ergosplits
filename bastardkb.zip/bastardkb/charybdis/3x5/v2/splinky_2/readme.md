# Splinky controller

The splinky is a Pro-Micro/Elite-C replacement with USB-C and RP2040.

See [plut0nium/0xB2](https://github.com/plut0nium/0xB2/#releases) to figure out the right version for you (v2 or v3).
