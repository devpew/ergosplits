# Next generation Dilemma keyboard

This keyboard is an updated version of the [3x5+2 Dilemma](../3x5_2/).

This is still under active development, and not available publicly yet.
