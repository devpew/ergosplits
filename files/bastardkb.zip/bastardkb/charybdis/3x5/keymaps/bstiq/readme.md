# Charybdis (3x5) @bstiq keymap

Inspired from Miryoku, using home-rows.
