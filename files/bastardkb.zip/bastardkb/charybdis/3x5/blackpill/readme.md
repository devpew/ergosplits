# Charybdis Nano (3x5) BlackPill

An ergonomic keyboard with integrated trackball, with BlackPill (STM32F411) mod.
