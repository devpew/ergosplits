# Charybdis Mini (3x6) BlackPill

An ergonomic keyboard with integrated trackball, with BlackPill (STM32F411) mod.
