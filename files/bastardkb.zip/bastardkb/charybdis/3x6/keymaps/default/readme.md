# Charybdis Mini (3x6) default keymap

> :bulb: Have a look at the [`via` keymap](../via) for a more feature-rich layout.

The Charydbis Mini (3x6) default keymap is inspired from the original [Dactyl Manuform](../../../../../handwired/dactyl_manuform) default keymap.

This layout supports RGB matrix. However, due to space constraints on the MCU, only a limited number of effect can be enabled at once. Look at the `config.h` file and enable your favorite effect.
